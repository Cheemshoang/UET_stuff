n = float(input())

tron_xuong = int(n)


if n - int(n) > 0:
    tron_len = int(n) + 1
else:
    tron_len = int(n)



print(tron_xuong, tron_len)
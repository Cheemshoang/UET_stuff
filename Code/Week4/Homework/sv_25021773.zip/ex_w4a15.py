n = int(input())
if n >= 8:
    print("Gioi")
elif n >= 6.5:
    print("Kha")
elif n >= 5:
    print("Trung Binh")
else:
    print("Yeu")
    
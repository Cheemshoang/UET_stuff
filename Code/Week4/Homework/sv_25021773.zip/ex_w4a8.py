a, b = list(map(str, input().split()))
if len(a) > len(b):
    print("True")
else:
    print("False")
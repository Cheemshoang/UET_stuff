a, b = list(map(int, input().split()))
if a < 0 and b < 0:
    print("Yes")
else:
    print("No")
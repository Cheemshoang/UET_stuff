n = int(input())
if (n & (n-1)) == 0:
    print("Yes")
else:
    print("No")
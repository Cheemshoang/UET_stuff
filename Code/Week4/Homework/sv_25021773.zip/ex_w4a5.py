import math as m
a, b = list(map(int, input().split()))
print(m.ceil(a/b))
a, b = list(map(int, input().split()))
print(round(a/b))
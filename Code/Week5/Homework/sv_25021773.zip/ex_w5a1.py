n = int(input())
i = 1
a = 0
while i <= n:
    a += i
    i += 1

print(a)
    
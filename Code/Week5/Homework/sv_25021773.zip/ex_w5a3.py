n = int(input())

ans = 1
i = 1
while i <= n:
    ans *= i
    i += 1
print(ans)
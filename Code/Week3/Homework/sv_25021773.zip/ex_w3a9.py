a = int(input())
if a%2 == 0:
    print("so chan")
else:
    print("so le")
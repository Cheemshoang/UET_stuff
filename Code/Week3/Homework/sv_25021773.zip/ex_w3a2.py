import math as m 
a, b = map(int, input().split())

print(round(a*b - 3.14*a*a/4, 2))

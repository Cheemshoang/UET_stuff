n = int(input())
if n >= 8:
    print("Giỏi")
elif n >= 6.5:
    print("Khá")
elif n >= 5:
    print("Trung bình")
else:
    print("Yếu")
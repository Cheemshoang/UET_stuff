
n = int(input("Nhập số (0-9): "))

if n == 0:
    print("Không")
elif n == 1:
    print("Một")
elif n == 2:
    print("Hai")
elif n == 3:
    print("Ba")
elif n == 4:
    print("Bốn")
elif n == 5:
    print("Năm")
elif n == 6:
    print("Sáu")
elif n == 7:
    print("Bảy")
elif n == 8:
    print("Tám")
elif n == 9:
    print("Chín")

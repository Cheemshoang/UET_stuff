n = int(input())
if n%10 == 5:
    print("True")
else:
    print("False")
c = str(input())
if  40 < ord(c[0]) < 91 or 96 < ord(c[0]) < 123:
    print(f"{c} day la chu")
elif 47 < ord(c[0]) < 58:
    print(f"{c} day la so")
         
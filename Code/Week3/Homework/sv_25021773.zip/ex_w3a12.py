n= int(input("Nhập năm sinh: "))


t = 2025 - n

if t >= 18:
    print("Đủ")
else:
    print("Chưa đủ")
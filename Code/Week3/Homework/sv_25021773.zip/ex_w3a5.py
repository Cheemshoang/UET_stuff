c = str(input())
if 65 < ord(c[0]) < 91: 
    print(chr(ord(c[0])+31))

elif c[0] == "A":
    print("Dac Biet")
    
        

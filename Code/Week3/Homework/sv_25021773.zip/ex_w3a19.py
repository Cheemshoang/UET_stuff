n= int(input("Nhập năm sinh: "))


t = 2025 - n

if t >= 18:
    print("Đủ 18")
else:
    print("Chưa đủ 18")
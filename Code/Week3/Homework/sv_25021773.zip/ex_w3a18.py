n = float(input("Nhập điểm thi: "))

if n >= 4:
    print("Qua môn")
else:
    print("Học lại")
s = str(input())
a = s[4]
b = s[8]
print(f"chu cai 5: {a} va chu cai 9: {b}")
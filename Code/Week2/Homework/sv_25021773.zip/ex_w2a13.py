import math as m
a, b = map(float, input().split())
print(m.floor(a*b))
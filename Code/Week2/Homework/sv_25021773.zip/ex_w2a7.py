a = ((13**2)*3)+5
b = 13**2*3+5
print(a)
print(b)
x,y,z = map(str, input().split())
print(f"Hi {z}, {y} and {x}")

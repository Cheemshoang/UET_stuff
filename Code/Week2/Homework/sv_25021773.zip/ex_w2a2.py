s = str(input())
print("Hello", s)
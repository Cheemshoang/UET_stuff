x = float(input())
print(round((x+10)*1.4, 2))
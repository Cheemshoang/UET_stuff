x1, y1, z1, x2, y2, x3  = map(int, input().split())
print((x1+y1+z1+2*x2+2*y2+3*x3)/10)
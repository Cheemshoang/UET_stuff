n = int(input())
print(6*n*(n-1)-1)
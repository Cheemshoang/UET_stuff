a = input()
print(ord(a))
print(chr(ord(a)-32))
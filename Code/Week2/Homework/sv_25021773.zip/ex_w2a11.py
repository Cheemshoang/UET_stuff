a,b = map(int, input().split())
time = (a*60+b)*60
print(f"second: ", time)

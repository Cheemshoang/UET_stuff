print("*")
print("***")
print("*****")
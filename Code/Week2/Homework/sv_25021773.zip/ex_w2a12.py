n = int(input())
print(6*n**2)
a = float(input())
b = round(float((1.8 * a + 32)),2)
print(b)
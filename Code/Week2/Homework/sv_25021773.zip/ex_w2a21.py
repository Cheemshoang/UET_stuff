i = 0;
while(i < 10):
    print("Hello, world")
    i += 1